from django.apps import AppConfig


class HealthcareappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'healthcareapp'
